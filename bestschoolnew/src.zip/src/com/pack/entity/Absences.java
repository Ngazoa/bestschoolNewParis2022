package com.pack.entity;

public class Absences {
	private int nonJustifieSeq1 = 0;
	private int justifieSeq1 = 0;
	private int nonJustifieSeq2 = 0;
	private int justifieSeq2 = 0;
	private int nonJustifieSeq3 = 0;
	private int justifieSeq3 = 0;
	private int nonJustifieSeq4 = 0;
	private int justifieSeq4 = 0;
	private int nonJustifieSeq5 = 0;
	private int justifieSeq5 = 0;
	private int nonJustifieSeq6 = 0;
	private int justifieSeq6 = 0;
	
	public int getNonJustifieSeq1() {
		return nonJustifieSeq1;
	}
	public Absences setNonJustifieSeq1(int nonJustifieSeq1) {
		this.nonJustifieSeq1 = nonJustifieSeq1;
		return this;
	}
	public int getJustifieSeq1() {
		return justifieSeq1;
	}
	public Absences setJustifieSeq1(int justifieSeq1) {
		this.justifieSeq1 = justifieSeq1;
		return this;
	}
	public int getNonJustifieSeq2() {
		return nonJustifieSeq2;
	}
	public Absences setNonJustifieSeq2(int nonJustifieSeq2) {
		this.nonJustifieSeq2 = nonJustifieSeq2;
		return this;
	}
	public int getJustifieSeq2() {
		return justifieSeq2;
	}
	public Absences setJustifieSeq2(int justifieSeq2) {
		this.justifieSeq2 = justifieSeq2;
		return this;
	}
	public int getNonJustifieSeq3() {
		return nonJustifieSeq3;
	}
	public Absences setNonJustifieSeq3(int nonJustifieSeq3) {
		this.nonJustifieSeq3 = nonJustifieSeq3;
		return this;
	}
	public int getJustifieSeq3() {
		return justifieSeq3;
	}
	public Absences setJustifieSeq3(int justifieSeq3) {
		this.justifieSeq3 = justifieSeq3;
		return this;
	}
	public int getNonJustifieSeq4() {
		return nonJustifieSeq4;
	}
	public Absences setNonJustifieSeq4(int nonJustifieSeq4) {
		this.nonJustifieSeq4 = nonJustifieSeq4;
		return this;
	}
	public int getJustifieSeq4() {
		return justifieSeq4;
	}
	public Absences setJustifieSeq4(int justifieSeq4) {
		this.justifieSeq4 = justifieSeq4;
		return this;
	}
	public int getNonJustifieSeq5() {
		return nonJustifieSeq5;
	}
	public Absences setNonJustifieSeq5(int nonJustifieSeq5) {
		this.nonJustifieSeq5 = nonJustifieSeq5;
		return this;
	}
	public int getJustifieSeq5() {
		return justifieSeq5;
	}
	public Absences setJustifieSeq5(int justifieSeq5) {
		this.justifieSeq5 = justifieSeq5;
		return this;
	}
	public int getNonJustifieSeq6() {
		return nonJustifieSeq6;
	}
	public Absences setNonJustifieSeq6(int nonJustifieSeq6) {
		this.nonJustifieSeq6 = nonJustifieSeq6;
		return this;
	}
	public int getJustifieSeq6() {
		return justifieSeq6;
	}
	public Absences setJustifieSeq6(int justifieSeq6) {
		this.justifieSeq6 = justifieSeq6;
		return this;
	}
	
	
	
	
}
