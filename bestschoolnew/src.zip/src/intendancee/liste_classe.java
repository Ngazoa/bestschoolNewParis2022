/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package intendancee;

/**
 *
 * @author Michelle Wafo
 */
public class liste_classe {
       
    
    private String classe;
    ;

    public liste_classe () {
    }

    public liste_classe ( String firstName) {
        this.classe= firstName;
        
    }

    public String getliste_class () {
        return classe;
    }

    public void setliste_class (String username) {
        this.classe= username;
    }
    
}
