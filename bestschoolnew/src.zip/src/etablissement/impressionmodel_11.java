/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package etablissement;

import java.io.Serializable;

/**
 *
 * @author Michelle Wafo
 */
public class impressionmodel_11 implements Serializable{
      private String nom,date,lnaissance,sexe,classe,photo;
      private String total,moyenne,rang,ra1,ra2,ra23,ra24,ra25,ra26,ra27,ra3,ra4,ra5,ra6,ra7,ra8,ra9,ra10,ra11,ra12,ra13,ra14,ra15,ra16,ra17,ra18,ra19,ra20,ra21,ra22
              ,rb1,rb2,rb23,rb24,rb25,rb26,rb3,rb4,rb5,rb6,rb7,rb8,rb9,rb10,rb11,rb12,rb13,rb14,rb15,rb16,rb17,rb18,rb19,rb20,rb21,rb22,
              rc1,rc2,rc23,rc24,rc25,rc26,rc27,rc28,rc3,rc4,rc5,rc6,rc7,rc8,rc9,rc10,rc11,rc12,rc13,rc14,rc15,rc16,rc17,rc18,rc19,rc20,rc21,rc22;
      private String rd, id_eleve,r1,r2,r23,r24,r25,r26,r3,r4,r5,r6,r7,r8,r9,r10,r11,r12,r13,r14,r15,r16,r17,r18,r19,r20,r21,r22,ts31,
 ts51,ts52,ts523,ts524,ts525,ts526,ts53,ts54,ts55,ts56,ts57,ts58,ts59,ts510,ts511,ts512,ts513,ts514,ts515,ts516,ts517,ts518,ts519,ts520,ts521,ts522
 ,ts61,ts62,ts623,ts624,ts625,ts626,ts63,ts64,ts65,ts66,ts67,ts68,ts69,ts610,ts611,ts612,ts613,ts614,ts615,ts616,ts617,ts618,ts619,ts620,ts621,ts622
 ,ts41,ts42,ts423,ts424,ts425,ts426,ts43,ts44,ts45,ts46,ts47,ts48,ts49,ts410,ts411,ts412,ts413,ts414,ts415,ts416,ts417,ts418,ts419,ts420,ts421,ts422
, ts32,ts323,ts324,ts325,ts326,ts327,ts33,ts34,ts35,ts36,ts37,ts38,ts39,ts310,ts311,ts312,ts313,ts314,ts315,ts316,ts317,ts318,ts319,ts320,ts321,ts322,
 note1,note2,note23,note24,note25,note26,note3,note4,note5,note6,note7,note8,note9,note10,note11,note12,note13,note14,note15,note16,note17,note18,note19,
 note20,note21,note22,note1a,note2a,note23a,note24a,note25a,note26a,note3a,note4a,note5a,note6a,note7a,note8a,note9a,note10a,note11a,note12a,note13a,
note14a,note15a,note16a,note17a,note18a,note19a,note20a,note21a,note22a,ansencejustifiee,ansencenonjustifiee,matricule;
   
       public void ansencejustifiee(String s) {
        this.ansencejustifiee= s;
    }
    
     public String ansencejustifiee() {
        return ansencejustifiee;
    }    public void matricule(String s) {
        this.matricule= s;
    }  public String photo() {
        return photo;
    }    public void photo(String s) {
        this.photo= s;
    }
    
     public String matricule() {
        return matricule;
    }
  public void ansencenonjustifiee(String s) {
        this.ansencenonjustifiee= s;
    }
    
     public String ansencenonjustifiee() {
        return ansencenonjustifiee;
    }
//  
//        this.nom = name;
//        this.date= date;
//        this.lnaissance = lnaissance;
//        this.sexe= sexe;
//        this.classe=classe;
//        this.note1=note1;
//        this.note2=note2;
//        this.note3=note3;
//        this.note4=note4;
//        this.note5=note5;
//        this.note6=note6;
//        this.note7=note7;
//        this.note8=note8;
//        this.note9=note9;
//        this.note10=note10;
//        this.note11=note11;
//        this.note12=note12;
//        this.note13=note13;
//        this.note14=note14;
//        this.note15=note15;
//        this.note16=note16;
//        this.note17=note17;
//        this.note18=note18;
//        this.note19=note19;
//        this.note20=note20;
//        this.note21=note21;
//        note22=note22;

      public void sexe(String s) {
        this.sexe= s;
    }
    
     public String sexe() {
        return sexe;
    }  
     public void r1(String s) {
        this.r1= s;
    }
    //rang trim 1
     public String r1() {
        return r1;
    } 
     public void id_eleve(String s) {
        this.id_eleve= s;
    }
    //rang trim 1
     public String id_eleve() {
        return id_eleve;
    } 
    public void r2(String s) {
        this.r2= s;
    }
    
     public String r2() {
        return r2;
    }public void r20(String s) {
        this.r20= s;
    }
    
     public String r20() {
        return r20;
    }public void r21(String s) {
        this.r21= s;
    }
    
     public String r21() {
        return r21;
    }
     public void r22(String s) {
        this.r22= s;
    }
    
     public String r22() {
        return r22;
    }
     
     
      public void r26(String s) {
        this.r26= s;
    }
    
     public String r26() {
        return r26;
    }  public void r23(String s) {
        this.r23= s;
    }
    
     public String r23() {
        return r23;
    }  public void r24(String s) {
        this.r24= s;
    }
    
     public String r24() {
        return r24;
    }  public void r25(String s) {
        this.r25= s;
    }
    
     public String r25() {
        return r25;
    }
     
     
     public void r3(String s) {
        this.r3= s;
    }
    
     public String r3() {
        return r3;
    } 
  public void r4(String s) {
        this.r4= s;
    }
    
     public String r4() {
        return r4;
    } 
     public void r5(String s) {
        this.r5= s;
    }
    
     public String r5() {
        return r5;
    } 
    public void r6(String s) {
        this.r6= s;
    }
    
     public String r6() {
        return r6;
    }  
     public void r7(String s) {
        this.r7= s;
    }
    
     public String r7() {
        return r7;
    } 
     public void r8(String s) {
        this.r8= s;
    }
    
     public String r8() {
        return r8;
    } 
    public void r9(String s) {
        this.r9= s;
    }
    
     public String r9() {
        return r9;
    } public void r10(String s) {
        this.r10= s;
    }   
    
     public String r10() {
        return r10;
    } 
     
     public void r11(String s) {
        this.r11= s;
    } 
     
     public String r11() {
        return r11;
    } 
    public void r12(String s) {
        this.r12= s;
    }
    
     public String r12() {
        return r12;
    }
     public void r13(String s) {
        this.r13= s;
    }
    
     public String r13() {
        return r13;
    } 
  public void r14(String s) {
        this.r14= s;
    }
    
     public String r14() {
        return r14;
    } 
     public void r15(String s) {
        this.r15= s;
    }
    
     public String r15() {
        return r15;
    } 
    public void r16(String s) {
        this.r16= s;
    }
    
     public String r16() {
        return r16;
    }  
     public void r17(String s) {
        this.r17= s;
    }
    
     public String r17() {
        return r17;
    } 
     public void r18(String s) {
        this.r18= s;
    }
    
     public String r18() {
        return r18;
    } 
    public void r19(String s) {
        this.r19= s;
    }
    
     public String ra19() {
        return ra19;
     }
     
      public String ra1() {
        return ra1;
    } 
    public void ra1(String s) {
        this.ra1= s;
        
    } public void ra2(String s) {
        this.ra2= s;
    }
    
     public String ra2() {
        return ra2;
    }public void ra20(String s) {
        this.ra20= s;
    }
    
     public String ra20() {
        return ra20;
    }public void ra21(String s) {
        this.ra21= s;
    }
    
     public String ra21() {
        return ra21;
    }
     public void ra22(String s) {
        this.ra22= s;
    }
    
     public String ra22() {
        return ra22;
    }
       public void ra23(String s) {
        this.ra23= s;
    }
    
     public String ra23() {
        return ra23;
    }
      public void ra24(String s) {
        this.ra24= s;
    }
    
     public String ra24() {
        return ra24;
    } 
       public void ra25(String s) {
        this.ra25= s;
    }
    
     public String ra25() {
        return ra25;
    }
     public void ra3(String s) {
        this.ra3= s;
    }
    
     public String ra3() {
        return ra3;
    } 
  public void ra4(String s) {
        this.ra4= s;
    }
    
     public String ra4() {
        return ra4;
    } 
     public void ra5(String s) {
        this.ra5= s;
    }
    
     public String ra5() {
        return ra5;
    } 
    public void ra6(String s) {
        this.ra6= s;
    }
    
     public String ra6() {
        return ra6;
    }  
     public void ra7(String s) {
        this.ra7= s;
    }
    
     public String ra7() {
        return ra7;
    } 
     public void ra8(String s) {
        this.ra8= s;
    }
    
     public String ra8() {
        return ra8;
    } 
    public void ra9(String s) {
        this.ra9= s;
    }
    
     public String ra9() {
        return ra9;
    } public void ra10(String s) {
        this.ra10= s;
    }
    
    
    
     public String ra10() {
        return ra10;
    } 
     
     public void ra11(String s) {
        this.ra11= s;
    } 
     
     public String ra11() {
        return ra11;
    } 
    public void ra12(String s) {
        this.ra12= s;
    }
    
     public String ra12() {
        return ra12;
    }
     public void ra13(String s) {
        this.ra13= s;
    }
    
     public String ra13() {
        return ra13;
    } 
  public void ra14(String s) {
        this.ra14= s;
    }
    
     public String ra14() {
        return ra14;
    } 
     public void ra15(String s) {
        this.ra15= s;
    }
    
     public String ra15() {
        return ra15;
    } 
    public void ra16(String s) {
        this.ra16= s;
    }
    
     public String ra16() {
        return ra16;
    }  
     public void ra17(String s) {
        this.ra17= s;
    }
    
     public String ra17() {
        return ra17;
    } 
     public void ra18(String s) {
        this.ra18= s;
    }
    
     public String ra18() {
        return ra18;
    } 
    public void ra19(String s) {
        this.ra19= s;
    }
    
     
     public String r19() {
        return r19;
     }
     
     //rang trim 2
      public String rb1() {
        return rb1;
    } 
    public void rb1(String s) {
        this.rb1= s;
    }
    
     public String rb2() {
        return rb2;
    }
     public void rb20(String s) {
        this.rb20= s;
    } 
     public void rb2(String s) {
        this.rb2= s;
    }
    
     public String rb20() {
        return rb20;
    }public void rb21(String s) {
        this.rb21= s;
    }
    
     public String rb21() {
        return rb21;
    }
     public void rb22(String s) {
        this.rb22= s;
    }
    
     public String rb22() {
        return rb22;
    }
     
      public void rb26(String s) {
        this.rb26= s;
    }
    
     public String rb26() {
        return rb26;
    } public void rb23(String s) {
        this.rb23= s;
    }
    
     public String rb23() {
        return rb23;
    } public void rb24(String s) {
        this.rb24= s;
    }
    
     public String rb24() {
        return rb24;
    } public void rb25(String s) {
        this.rb25= s;
    }
    
     public String rb25() {
        return rb25;
    }
     
     public void rb3(String s) {
        this.rb3= s;
    }
    
     public String rb3() {
        return rb3;
    } 
  public void rb4(String s) {
        this.rb4= s;
    }
    
     public String rb4() {
        return rb4;
    } 
     public void rb5(String s) {
        this.rb5= s;
    }
    
     public String rb5() {
        return rb5;
    } 
    public void rb6(String s) {
        this.rb6= s;
    }
    
     public String rb6() {
        return rb6;
    }  
     public void rb7(String s) {
        this.rb7= s;
    }
    
     public String rb7() {
        return rb7;
    } 
     public void rb8(String s) {
        this.rb8= s;
    }
    
     public String rb8() {
        return rb8;
    } 
    public void rb9(String s) {
        this.rb9= s;
    }
    
     public String rb9() {
        return rb9;
    } public void rb10(String s) {
        this.rb10= s;
    }
    
    
    
     public String rb10() {
        return rb10;
    } 
     
     public void rb11(String s) {
        this.rb11= s;
    } 
     
     public String rb11() {
        return rb11;
    } 
    public void rb12(String s) {
        this.rb12= s;
    }
    
     public String rb12() {
        return rb12;
    }
     public void rb13(String s) {
        this.rb13= s;
    }
    
     public String rb13() {
        return rb13;
    } 
  public void rb14(String s) {
        this.rb14= s;
    }
    
     public String rb14() {
        return rb14;
    } 
     public void rb15(String s) {
        this.rb15= s;
    }
    
     public String rb15() {
        return rb15;
    } 
    public void rb16(String s) {
        this.rb16= s;
    }
    
     public String rb16() {
        return rb16;
    }  
     public void rb17(String s) {
        this.rb17= s;
    }
    
     public String rb17() {
        return rb17;
    } 
     public void rb18(String s) {
        this.rb18= s;
    }
    
     public String rb18() {
        return rb18;
    } 
    public void rb19(String s) {
        this.rb19= s;
    }
    
     public String rb19() {
        return rb19;
     }
     
     //rang annuel
     
      public String rc1() {
        return rc1;
    } 
       public void rc1(String s) {
        this.rc1= s;
    }
    public void rc2(String s) {
        this.rc2= s;
    }
    
     public String rc2() {
        return rc2;
    }public void rc20(String s) {
        this.rc20= s;
    }
    
     public String rc20() {
        return rc20;
    }public void rc21(String s) {
        this.rc21= s;
    }
    
     public String rc21() {
        return rc21;
    }
     public void rc22(String s) {
        this.rc22= s;
    }
    
     public String rc22() {
        return rc22;
    } public void rc26(String s) {
        this.rc26= s;
    }
    
     public String rc26() {
        return rc26;
    } public void rc23(String s) {
        this.rc23= s;
    }
    
     public String rc23() {
        return rc23;
    } public void rc25(String s) {
        this.rc25= s;
    }
    
     public String rc24() {
        return rc24;
    } public void rc24(String s) {
        this.rc24= s;
    }
    
     public String rc25() {
        return rc25;
    }
     public void rc3(String s) {
        this.rc3= s;
    }
    
     public String rc3() {
        return rc3;
    } 
  public void rc4(String s) {
        this.rc4= s;
    }
    
     public String rc4() {
        return rc4;
    } 
     public void rc5(String s) {
        this.rc5= s;
    }
    
     public String rc5() {
        return rc5;
    } 
    public void rc6(String s) {
        this.rc6= s;
    }
    
     public String rc6() {
        return rc6;
    }  
     public void rc7(String s) {
        this.rc7= s;
    }
    
     public String rc7() {
        return rc7;
    } 
     public void rc8(String s) {
        this.rc8= s;
    }
    
     public String rc8() {
        return rc8;
    } 
    public void rc9(String s) {
        this.rc9= s;
    }
    
     public String rc9() {
        return rc9;
    } public void rc10(String s) {
        this.rc10= s;
    }
    
    
    
     public String rc10() {
        return rc10;
    } 
     
     public void rc11(String s) {
        this.rc11= s;
    } 
     
     public String rc11() {
        return rc11;
    } 
    public void rc12(String s) {
        this.rc12= s;
    }
    
     public String rc12() {
        return rc12;
    }
     public void rc13(String s) {
        this.rc13= s;
    }
    
     public String rc13() {
        return rc13;
    } 
  public void rc14(String s) {
        this.rc14= s;
    }
    
     public String rc14() {
        return rc14;
    } 
     public void rc15(String s) {
        this.rc15= s;
    }
    
     public String rc15() {
        return rc15;
    } 
    public void rc16(String s) {
        this.rc16= s;
    }
    
     public String rc16() {
        return rc16;
    }  
     public void rc17(String s) {
        this.rc17= s;
    }
    
     public String rc17() {
        return rc17;
    } 
     public void rc18(String s) {
        this.rc18= s;
    }
    
     public String rc18() {
        return rc18;
    } 
    public void rc19(String s) {
        this.rc19= s;
    }
    
     public String rc19() {
        return rc19;
     }
     
   //_______________________________________  
     public void total(String s) {
        this.total= s;
    }
    
     public String  total() {
        return total;
    }  public void moyenne(String s) {
        this.moyenne= s;
    }
    
     public String  moyenne() {
        return moyenne;
    }
                                        
   public void classe(String s) {
        this.classe= s;
    }
    
     public String classe() {
        return classe;
    }
 
     public String nom() {
        return nom;
    }

    public void nom(String s) {
        this.nom= s;
    }
    
     public String date() {
        return date;
    }

    public void rd(String s) {
        this.rd= s;
    }  public String rd() {
        return rd;
    }

    public void date(String s) {
        this.date= s;
    }
    
     public String lnaissance() {
        return lnaissance;
    } 
     
    public void lnaissance(String s) {
        this.lnaissance= s;
    }
    
     public String note1() {
        return note1;
    }

    public void note1(String s) {
        this.note1= s;
    }
       public String note2() {
        return note2;
    }

    public void note2(String s) {
        this.note2= s;
    }
       public String note3() {
        return note3;
    }

    public void note3(String s) {
        this.note3= s;
    }
       public String note4() {
        return note4;
    }

    public void note4(String s) {
        this.note4= s;
    }
       public String note5() {
        return note5;
    }

    public void note5(String s) {
        this.note5= s;
    }
       public String note6() {
        return note6;
    }

    public void note6(String s) {
        this.note6= s;
    }
       public String note7() {
        return note7;
    }

    public void note7(String s) {
        this.note7= s;
    }
       public String note8() {
        return note8;
    }

    public void note8(String s) {
        this.note8= s;
    }
       public String note9() {
        return note9;
    }

    public void note9(String s) {
        this.note9= s;
    }   public String note10() {
        return note10;
    }

    public void note10(String s) {
        this.note10= s;
    }
       public String note11() {
        return note11;
    }

    public void note11(String s) {
        this.note11= s;
    }
       public String note12() {
        return note12;
    }

    public void note12(String s) {
        this.note12= s;
    }   public String note13() {
        return note13;
    }

    public void note13(String s) {
        this.note13= s;
    }   public String note14() {
        return note14;
    }

    public void note14(String s) {
        this.note14= s;
    }   public String note15() {
        return note15;
    }

    public void note15(String s) {
        this.note15= s;
    }   public String note16() {
        return note16;
    }

    public void note16(String s) {
        this.note16= s;
    }   public String note17() {
        return note17;
    }

    public void note17(String s) {
        this.note17= s;
    }   public String note18() {
        return note18;
    }

    public void note18(String s) {
        this.note18= s;
    }   public String note19() {
        return note19;
    }

    public void note19(String s) {
        this.note19= s;
    }   public String note20() {
        return note20;
    }

    public void note20(String s) {
        this.note20= s;
    }   public String note21() {
        return note21;
    }

    public void note21(String s) {
        this.note21= s;
    }   public String note22() {
        return note22;
    }
 public void note23(String s) {
        this.note23= s;
    }   public String note23() {
        return note23;
    } public void note24(String s) {
        this.note24= s;
    }   public String note24() {
        return note24;
    } public void note25(String s) {
        this.note25= s;
    }   public String note25() {
        return note25;
    } public void note26(String s) {
        this.note26= s;
    }   public String note26() {
        return note26;
    }
    public void note22(String s) {
        this.note22= s;
    }  public String rang() {
        return rang;
    }
 public String note1a() {
        return note1a;
    }

    public void note1a(String s) {
        this.note1a= s;
    }
       public String note2a() {
        return note2a;
    }

    public void note2a(String s) {
        this.note2a= s;
    }
       public String note3a() {
        return note3a;
    }

    public void note3a(String s) {
        this.note3a= s;
    }
       public String note4a() {
        return note4a;
    }

    public void note4a(String s) {
        this.note4a= s;
    }
       public String note5a() {
        return note5a;
    }

    public void note5a(String s) {
        this.note5a= s;
    }
       public String note6a() {
        return note6a;
    }

    public void note6a(String s) {
        this.note6a= s;
    }
       public String note7a() {
        return note7a;
    }

    public void note7a(String s) {
        this.note7a= s;
    }
       public String note8a() {
        return note8a;
    }

    public void note8a(String s) {
        this.note8a= s;
    }
       public String note9a() {
        return note9a;
    }

    public void note9a(String s) {
        this.note9a= s;
    }   public String note10a() {
        return note10a;
    }

    public void note10a(String s) {
        this.note10a= s;
    }
       public String note11a() {
        return note11a;
    }

    public void note11a(String s) {
        this.note11a= s;
    }
       public String note12a() {
        return note12a;
    }

    public void note12a(String s) {
        this.note12a= s;
    }   public String note13a() {
        return note13a;
    }

    public void note13a(String s) {
        this.note13a= s;
    }   public String note14a() {
        return note14a;
    }

    public void note14a(String s) {
        this.note14a= s;
    }   public String note15a() {
        return note15a;
    }

    public void note15a(String s) {
        this.note15a= s;
    }   public String note16a() {
        return note16a;
    }

    public void note16a(String s) {
        this.note16a= s;
    }   public String note17a() {
        return note17a;
    }

    public void note17a(String s) {
        this.note17a= s;
    }   public String note18a() {
        return note18a;
    }

    public void note18a(String s) {
        this.note18a= s;
    }   public String note19a() {
        return note19a;
    }

    public void note19a(String s) {
        this.note19a= s;
    }   public String note20a() {
        return note20a;
    }

    public void note20a(String s) {
        this.note20a= s;
    }   public String note21a() {
        return note21a;
    }

    public void note21a(String s) {
        this.note21a= s;
    }   
    
    public String note22a() {
        return note22a;
    }

    public void note22a(String s) {
        this.note22a= s;
    }public String note23a() {
        return note23a;
    }

    public void note23a(String s) {
        this.note23a= s;
    }public String note24a() {
        return note24a;
    }

    public void note24a(String s) {
        this.note24a= s;
    }public String note25a() {
        return note25a;
    }

    public void note25a(String s) {
        this.note25a= s;
    } 

    public void rang(String s) {
        this.rang= s;
    }
    
    //sequence 3
    
    public String ts31() {
        return ts31;
    }

    public void ts31(String s) {
        this.ts31= s;
    }
       public String ts32() {
        return ts32;
    }
public void ts32(String s) {
        this.ts32= s;
    }
    public void ts33(String s) {
        this.ts33= s;
    }
       public String ts33() {
        return ts33;
    }

    public void ts34(String s) {
        this.ts34= s;
    }      public String ts34() {
        return ts34;
    }

    public void ts35(String s) {
        this.ts35= s;
    }
       public String ts35() {
        return ts35;
    }

    public void ts36(String s) {
        this.ts36= s;
    }
       public String ts36() {
        return ts36;
    }

       public String ts37() {
        return ts37;
    }public void ts37(String s) {
        this.ts37= s;
    }
       
    public String ts38() {
        return ts38;
    }

    public void ts38(String s) {
        this.ts38= s;
    }
       public String ts39() {
        return ts39;
    }

    public void ts39(String s) {
        this.ts39= s;
    }   public String ts310() {
        return ts310;
    }

    public void ts311(String s) {
        this.ts311= s;
    }
       public String ts311() {
        return ts311;
    }

    public void ts310(String s) {
        this.ts310= s;
    } public void ts312(String s) {
        this.ts312= s;
    }
       public String ts312() {
        return ts312;
    }

    public void ts313(String s) {
        this.ts313= s;
    }   public String ts313() {
        return ts313;
    }

    public void ts314(String s) {
        this.ts314= s;
    }   public String ts314() {
        return ts314;
    }

    public void ts315(String s) {
        this.ts315= s;
    }   public String ts315() {
        return ts315;
    }

    public void ts316(String s) {
        this.ts316= s;
    }   public String ts316() {
        return ts316;
    }

    public void ts317(String s) {
        this.ts317= s;
    }   public String ts317() {
        return ts317;
    }

    public void ts318(String s) {
        this.ts318= s;
    }   public String ts318() {
        return ts318;
    }

    public void ts319(String s) {
        this.ts319= s;
    }   public String ts319() {
        return ts319;
    }

    public void ts320(String s) {
        this.ts320= s;
    }   public String ts320() {
        return ts320;
    }

    public void ts321(String s) {
        this.ts321= s;
    }   public String ts321() {
        return ts321;
    }

    public void ts322(String s) {
        this.ts322= s;
    }   public String ts322() {
        return ts322;
    }
public void ts323(String s) {
        this.ts323= s;
    }   public String ts323() {
        return ts323;
    }
    public void ts324(String s) {
        this.ts324= s;
    }   public String ts324() {
        return ts324;
    }
    public void ts325(String s) {
        this.ts325= s;
    }   public String ts325() {
        return ts325;
    }
    public void ts326(String s) {
        this.ts326= s;
    }   public String ts326() {
        return ts326;
    }
   //s4 
     
     public String ts41() {
        return ts41;
    }

    public void ts41(String s) {
        this.ts41= s;
    }
       public String ts42() {
        return ts42;
    }

    public void ts43(String s) {
        this.ts43= s;
    }
       public String ts43() {
        return ts43;
    }

    public void ts44(String s) {
        this.ts44= s;
    }      public String ts44() {
        return ts44;
    }

    public void ts45(String s) {
        this.ts45= s;
    }
       public String ts45() {
        return ts45;
    }

    public void ts46(String s) {
        this.ts46= s;
    }
       public String ts46() {
        return ts46;
    }

       public String ts47() {
        return ts47;
    }public void ts47(String s) {
        this.ts47= s;
    }
       
    public String ts48() {
        return ts48;
    }

    public void ts48(String s) {
        this.ts48= s;
    }
       public String ts49() {
        return ts49;
    }

    public void ts49(String s) {
        this.ts49= s;
    }   public String ts410() {
        return ts410;
    }

    public void ts411(String s) {
        this.ts411= s;
    }
       public String ts411() {
        return ts411;
    }

    public void ts410(String s) {
        this.ts410= s;
    } 
     public void ts42(String s) {
        this.ts42= s;
    }
    
    public void ts412(String s) {
        this.ts412= s;
    }
       public String ts412() {
        return ts412;
    }

    public void ts413(String s) {
        this.ts413= s;
    }   public String ts413() {
        return ts413;
    }

    public void ts414(String s) {
        this.ts414= s;
    }   public String ts414() {
        return ts414;
    }

    public void ts415(String s) {
        this.ts415= s;
    }   public String ts415() {
        return ts415;
    }

    public void ts416(String s) {
        this.ts416= s;
    }   public String ts416() {
        return ts416;
    }

    public void ts417(String s) {
        this.ts417= s;
    }   public String ts417() {
        return ts417;
    }

    public void ts418(String s) {
        this.ts418= s;
    }   public String ts418() {
        return ts418;
    }

    public void ts419(String s) {
        this.ts419= s;
    }   public String ts419() {
        return ts419;
    }

    public void ts420(String s) {
        this.ts420= s;
    }   public String ts420() {
        return ts420;
    }

    public void ts421(String s) {
        this.ts421= s;
    }   public String ts421() {
        return ts421;
    }

    public void ts422(String s) {
        this.ts422= s;
    }   public String ts422() {
        return ts422;
    }
public void ts423(String s) {
        this.ts423= s;
    }   public String ts423() {
        return ts423;
    }public void ts424(String s) {
        this.ts424= s;
    }   public String ts424() {
        return ts424;
    }public void ts425(String s) {
        this.ts425= s;
    }   public String ts425() {
        return ts425;
    }public void ts426(String s) {
        this.ts426= s;
    }   public String ts426() {
        return ts426;
    }
    
    //SQ 5
   
     public String ts51() {
        return ts51;
    }

    public void ts51(String s) {
        this.ts51= s;
    }
       public String ts52() {
        return ts52;
    }
 public void ts52(String s) {
        this.ts52= s;
    }
    public void ts53(String s) {
        this.ts53= s;
    }
       public String ts53() {
        return ts53;
    }

    public void ts54(String s) {
        this.ts54= s;
    }      public String ts54() {
        return ts54;
    }

    public void ts55(String s) {
        this.ts55= s;
    }
       public String ts55() {
        return ts55;
    }

    public void ts56(String s) {
        this.ts56= s;
    }
       public String ts56() {
        return ts56;
    }

       public String ts57() {
        return ts57;
    }public void ts57(String s) {
        this.ts57= s;
    }
       
    public String ts58() {
        return ts58;
    }

    public void ts58(String s) {
        this.ts58= s;
    }
       public String ts59() {
        return ts59;
    }

    public void ts59(String s) {
        this.ts59= s;
    }   public String ts510() {
        return ts510;
    }

    public void ts511(String s) {
        this.ts511= s;
    }
       public String ts511() {
        return ts511;
    }

    public void ts510(String s) {
        this.ts510= s;
    }
       public String ts512() {
        return ts512;
    }

    public void ts513(String s) {
        this.ts513= s;
    }   public String ts513() {
        return ts513;
    }

    public void ts514(String s) {
        this.ts514= s;
    }   public String ts514() {
        return ts514;
    }

    public void ts515(String s) {
        this.ts515= s;
    }   public String ts515() {
        return ts515;
    }

    public void ts516(String s) {
        this.ts516= s;
    }   public String ts516() {
        return ts516;
    }

    public void ts517(String s) {
        this.ts517= s;
    }   public String ts517() {
        return ts517;
    }

    public void ts518(String s) {
        this.ts518= s;
    }   public String ts518() {
        return ts518;
    }

    public void ts519(String s) {
        this.ts519= s;
    }   public String ts519() {
        return ts519;
    }

    public void ts520(String s) {
        this.ts520= s;
    }   public String ts520() {
        return ts520;
    }

    public void ts521(String s) {
        this.ts521= s;
    }   public String ts521() {
        return ts521;
    }

    public void ts522(String s) {
        this.ts522= s;
    }   public String ts522() {
        return ts522;
    }
public void ts526(String s) {
        this.ts526= s;
    }   public String ts526() {
        return ts526;
    }public void ts523(String s) {
        this.ts523= s;
    }   public String ts523() {
        return ts523;
    }public void ts524(String s) {
        this.ts524= s;
    }   public String ts524() {
        return ts524;
    }public void ts525(String s) {
        this.ts525= s;
    }   public String ts525() {
        return ts525;
    }
   public String ts61() {
        return ts61;
    }

    public void ts61(String s) {
        this.ts61= s;
    }
    public void ts62(String s) {
        this.ts62= s;
    }
    
    public void ts612(String s) {
        this.ts612= s;
    }public void ts512(String s) {
        this.ts512= s;
    }
       public String ts62() {
        return ts62;
    }

    public void ts63(String s) {
        this.ts63= s;
    }
       public String ts63() {
        return ts63;
    }

    public void ts64(String s) {
        this.ts64= s;
    }      public String ts64() {
        return ts64;
    }

    public void ts65(String s) {
        this.ts65= s;
    }
       public String ts65() {
        return ts65;
    }

    public void ts66(String s) {
        this.ts66= s;
    }
       public String ts66() {
        return ts66;
    }

       public String ts67() {
        return ts67;
    }public void ts67(String s) {
        this.ts67= s;
    }
       
    public String ts68() {
        return ts68;
    }

    public void ts68(String s) {
        this.ts68= s;
    }
       public String ts69() {
        return ts69;
    }

    public void ts69(String s) {
        this.ts69= s;
    }   public String ts610() {
        return ts610;
    }

    public void ts611(String s) {
        this.ts611= s;
    }
       public String ts611() {
        return ts611;
    }

    public void ts610(String s) {
        this.ts610= s;
    }
       public String ts612() {
        return ts612;
    }

    public void ts613(String s) {
        this.ts613= s;
    }   public String ts613() {
        return ts613;
    }

    public void ts614(String s) {
        this.ts614= s;
    }   public String ts614() {
        return ts614;
    }

    public void ts615(String s) {
        this.ts615= s;
    }   public String ts615() {
        return ts615;
    }

    public void ts616(String s) {
        this.ts616= s;
    }   public String ts616() {
        return ts616;
    }

    public void ts617(String s) {
        this.ts617= s;
    }   public String ts617() {
        return ts617;
    }

    public void ts618(String s) {
        this.ts618= s;
    }   public String ts618() {
        return ts618;
    }

    public void ts619(String s) {
        this.ts619= s;
    }   public String ts619() {
        return ts619;
    }

    public void ts620(String s) {
        this.ts620= s;
    }   public String ts620() {
        return ts620;
    }

    public void ts621(String s) {
        this.ts621= s;
    }   public String ts621() {
        return ts621;
    }

    public void ts622(String s) {
        this.ts622= s;
    }   public String ts622() {
        return ts622;
    }
    
    public void ts626(String s) {
        this.ts626= s;
    }   public String ts626() {
        return ts626;
    }public void ts623(String s) {
        this.ts623= s;
    }   public String ts623() {
        return ts623;
    }public void ts624(String s) {
        this.ts624= s;
    }   public String ts624() {
        return ts624;
    }public void ts625(String s) {
        this.ts625= s;
    }   public String ts625() {
        return ts625;
    }
      
       
}
