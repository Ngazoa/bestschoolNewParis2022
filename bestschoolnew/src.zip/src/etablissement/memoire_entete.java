/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package etablissement;

/**
 *
 * @author Benito
 */
public class memoire_entete {
            public static String  hierarchieLevel1 = "Ministry of secondry education";
	     public static String  hierarchieLevel2 = "Regional delegation of Littoral";
	     public static String hierarchieLevel3 = "Depertmental  delegation of Wouri";
    
}
